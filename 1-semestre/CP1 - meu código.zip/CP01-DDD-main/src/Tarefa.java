public class Tarefa {

}

//professor no momento nao consigo entender java
//ta bem complicado mesmo entao... foi isso que consegui